"""
WebSocket Lambda Proxy Handler for LoveAndLaw
This Lambda function proxies WebSocket connections from API Gateway to the ECS service
"""

import json
import os
import boto3
import urllib3
from datetime import datetime, timedelta

# Initialize clients
dynamodb = boto3.resource('dynamodb')
http = urllib3.PoolManager()

# Configuration
ECS_SERVICE_URL = os.environ.get('ALB_URL', 'http://internal-alb.local')
CONNECTIONS_TABLE = os.environ.get('DYNAMODB_CONNECTIONS_TABLE', 'loveandlaw-websocket-connections')

# Get DynamoDB table
connections_table = dynamodb.Table(CONNECTIONS_TABLE)


def lambda_handler(event, context):
    """Main Lambda handler"""
    route_key = event.get('requestContext', {}).get('routeKey')
    connection_id = event.get('requestContext', {}).get('connectionId')
    
    print(f"Route: {route_key}, Connection: {connection_id}")
    
    # Initialize API Gateway Management API client with the correct endpoint
    domain_name = event.get('requestContext', {}).get('domainName')
    stage = event.get('requestContext', {}).get('stage')
    api_gateway = boto3.client(
        'apigatewaymanagementapi',
        endpoint_url=f'https://{domain_name}/{stage}'
    )
    
    try:
        if route_key == '$connect':
            return handle_connect(connection_id, event, api_gateway)
        elif route_key == '$disconnect':
            return handle_disconnect(connection_id)
        elif route_key == '$default':
            return handle_message(connection_id, event, api_gateway)
        else:
            return {'statusCode': 404, 'body': 'Route not found'}
    except Exception as e:
        print(f"Error: {str(e)}")
        return {'statusCode': 500, 'body': json.dumps({'error': str(e)})}


def handle_connect(connection_id, event, api_gateway):
    """Handle new WebSocket connection"""
    print(f"New connection: {connection_id}")
    
    # Store connection in DynamoDB
    connections_table.put_item(
        Item={
            'connectionId': connection_id,
            'connectedAt': datetime.utcnow().isoformat(),
            'ttl': int((datetime.utcnow() + timedelta(hours=24)).timestamp())
        }
    )
    
    # Send welcome message
    try:
        welcome_message = {
            "type": "connection_established",
            "connection_id": connection_id,
            "message": "Connected to Love & Law Assistant"
        }
        
        api_gateway.post_to_connection(
            ConnectionId=connection_id,
            Data=json.dumps(welcome_message)
        )
        print(f"Sent welcome message to {connection_id}")
    except Exception as e:
        print(f"Error sending welcome message: {str(e)}")
    
    return {'statusCode': 200, 'body': 'Connected'}


def handle_disconnect(connection_id):
    """Handle WebSocket disconnection"""
    print(f"Disconnecting: {connection_id}")
    
    # Remove from DynamoDB
    try:
        connections_table.delete_item(
            Key={'connectionId': connection_id}
        )
    except Exception as e:
        print(f"Error removing connection: {str(e)}")
    
    # Notify ECS
    try:
        http.request(
            'POST',
            f"{ECS_SERVICE_URL}/internal/websocket/disconnect",
            body=json.dumps({
                'connectionId': connection_id
            }),
            headers={
                'Content-Type': 'application/json',
                'X-Connection-Id': connection_id
            }
        )
    except Exception as e:
        print(f"Error notifying ECS of disconnect: {str(e)}")
    
    return {'statusCode': 200, 'body': 'Disconnected'}


def handle_message(connection_id, event, api_gateway):
    """Handle WebSocket message"""
    body = json.loads(event.get('body', '{}'))
    print(f"Message from {connection_id}: {body}")
    
    # Handle heartbeat directly in Lambda for better performance
    if body.get('type') == 'heartbeat':
        try:
            api_gateway.post_to_connection(
                ConnectionId=connection_id,
                Data=json.dumps({"type": "heartbeat", "timestamp": datetime.utcnow().isoformat()})
            )
            return {'statusCode': 200, 'body': 'Heartbeat sent'}
        except Exception as e:
            print(f"Error sending heartbeat: {str(e)}")
            return {'statusCode': 200, 'body': 'Heartbeat error'}
    
    # Prepare message for internal API
    internal_message = {
        'connectionId': connection_id,
        'type': body.get('type', 'user_msg'),
        'cid': body.get('cid'),
        'text': body.get('text'),
        'user_id': body.get('user_id'),
        'conversation_id': body.get('conversation_id')
    }
    
    # Forward message to ECS
    try:
        url = f"{ECS_SERVICE_URL}/internal/websocket/message"
        print(f"Forwarding message to ECS at: {url}")
        response = http.request(
            'POST',
            url,
            body=json.dumps(internal_message),
            headers={
                'Content-Type': 'application/json',
                'X-Connection-Id': connection_id
            },
            timeout=25  # API Gateway timeout is 29s, leave some buffer
        )
        
        if response.status == 200:
            # Parse ECS response
            response_data = response.data.decode('utf-8')
            print(f"ECS response data: {response_data[:200]}")  # Log first 200 chars
            ecs_response = json.loads(response_data)
            
            # Send responses back to client via API Gateway
            if 'messages' in ecs_response and ecs_response['messages']:
                # Multiple messages to send
                for msg in ecs_response['messages']:
                    send_to_connection(api_gateway, connection_id, msg)
                    # Small delay to ensure message ordering
                    import time
                    time.sleep(0.01)
            elif 'message' in ecs_response and ecs_response['message']:
                # Single message to send
                send_to_connection(api_gateway, connection_id, ecs_response['message'])
            else:
                print(f"No messages in ECS response: {ecs_response}")
            
            return {'statusCode': 200, 'body': 'Message processed'}
        else:
            print(f"ECS returned status: {response.status}")
            error_msg = {
                'type': 'error',
                'message': 'Service temporarily unavailable'
            }
            send_to_connection(api_gateway, connection_id, error_msg)
            return {'statusCode': 200, 'body': 'Error forwarded to client'}
            
    except urllib3.exceptions.TimeoutError:
        print("ECS request timed out")
        timeout_msg = {
            'type': 'error',
            'message': 'Request timed out'
        }
        send_to_connection(api_gateway, connection_id, timeout_msg)
        return {'statusCode': 200, 'body': 'Timeout'}
        
    except Exception as e:
        print(f"Error forwarding to ECS: {str(e)}")
        error_msg = {
            'type': 'error',
            'message': 'Internal server error'
        }
        send_to_connection(api_gateway, connection_id, error_msg)
        return {'statusCode': 200, 'body': 'Error'}


def send_to_connection(api_gateway, connection_id, message):
    """Send message to WebSocket connection"""
    try:
        api_gateway.post_to_connection(
            ConnectionId=connection_id,
            Data=json.dumps(message)
        )
        print(f"Sent message to {connection_id}: {message.get('type')}")
    except api_gateway.exceptions.GoneException:
        print(f"Connection {connection_id} is gone, removing from DynamoDB")
        try:
            connections_table.delete_item(
                Key={'connectionId': connection_id}
            )
        except Exception as e:
            print(f"Error removing stale connection: {str(e)}")
    except Exception as e:
        print(f"Error sending to connection: {str(e)}")